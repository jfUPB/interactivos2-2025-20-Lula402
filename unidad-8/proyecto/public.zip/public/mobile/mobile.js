let estadoActual = 4;
const socket = io();

const appContainer = document.getElementById('app-container');

function renderUIForState(estado) {
    appContainer.innerHTML = '';

    if (estado === 1) {
        const instruction = document.createElement('div');
        instruction.className = 'instruction-text';
        instruction.textContent = 'Mantén presionado para ser parte de la cascada';
        
        const ellipse = document.createElement('div');
        ellipse.className = 'touch-ellipse';

        const onPressStart = () => {
            ellipse.classList.add('active');
            socket.emit('state1_start_press');
            console.log('Enviado: state1_start_press');
        };

        const onPressEnd = () => {
            ellipse.classList.remove('active');
            socket.emit('state1_end_press');
            console.log('Enviado: state1_end_press');
        };

        ellipse.addEventListener('mousedown', onPressStart);
        ellipse.addEventListener('mouseup', onPressEnd);
        ellipse.addEventListener('mouseleave', onPressEnd);
        
        ellipse.addEventListener('touchstart', onPressStart);
        ellipse.addEventListener('touchend', onPressEnd);
        
        appContainer.appendChild(instruction);
        appContainer.appendChild(ellipse);
    }

    // ==========================================================
    //                        ESTADO 2
    // ==========================================================
    else if (estado === 2) {
         // --- Variables de control para la UI ---
        let isReady = true; // El botón empieza listo para ser usado
        const cooldownDuration = 3000; // 3 segundos de recarga

        // --- Creación de los elementos de la UI ---
        
        // 1. Crear el texto de instrucción.
        const instruction = document.createElement('div');
        instruction.className = 'instruction-text';
        instruction.textContent = 'Toca el orbe para generar una explosión de partículas';
        
        // 2. Crear el botón principal.
        const button = document.createElement('div');
        button.className = 'particle-button';
        
        // 3. Crear la capa de llenado para el cooldown.
        const fill = document.createElement('div');
        fill.className = 'fill';
        
        // 4. Crear la etiqueta de texto dentro del botón.
        const label = document.createElement('div');
        label.className = 'label';
        label.textContent = 'TAP';
        
        button.appendChild(fill);
        button.appendChild(label);


        const onButtonClick = () => {
  
            if (!isReady) return;

            isReady = false;
            button.classList.add('cooldown');

            socket.emit('state2_create_particles');
            console.log('Enviado: state2_create_particles');
            
            fill.style.transition = 'none';
            fill.style.transform = 'scaleY(0)';


            setTimeout(() => {
                fill.style.transition = `transform ${cooldownDuration}ms linear`;
                fill.style.transform = 'scaleY(1)';
            }, 10);
            
            setTimeout(() => {
                isReady = true;
                button.classList.remove('cooldown');
            }, cooldownDuration);
        };

        button.addEventListener('click', onButtonClick);

        appContainer.appendChild(instruction);
        appContainer.appendChild(button);
    }

    // ==========================================================
    //                        ESTADO 3
    // ==========================================================
  else if (estado === 3) {
        const imageNames = ["AWAY", "BE", "DID", "FROM", "LOVE", "Me", "MY", "TAKE", "YOU"];
        const instruction = document.createElement('div');
        instruction.className = 'instruction-text';
        instruction.textContent = 'Selecciona una imagen para la visualización:';
        appContainer.appendChild(instruction);

        const buttonContainer = document.createElement('div');
        buttonContainer.style.display = 'flex';
        buttonContainer.style.flexWrap = 'wrap';
        buttonContainer.style.justifyContent = 'center';
        appContainer.appendChild(buttonContainer);

        const buttons = [];

        imageNames.forEach(name => {
            const button = document.createElement('button');
            button.textContent = name;
            button.style.margin = '5px';
            button.style.padding = '10px 15px';
            button.style.fontSize = '16px';
            button.style.backgroundColor = '#333';
            button.style.color = 'white';
            button.style.border = '1px solid #555';
            button.style.borderRadius = '5px';
            button.style.cursor = 'pointer';
            buttonContainer.appendChild(button);
            buttons.push(button);

            button.addEventListener('click', () => {
                socket.emit('image_selection', `${name}.png`);
                console.log(`Enviado: image_selection - ${name}.png`);

                buttons.forEach(btn => {
                    btn.disabled = true;
                    btn.style.backgroundColor = '#555';
                    btn.style.cursor = 'default';
                });

                instruction.textContent = '¡Gracias por tu selección!';
            }, { once: true });
        });
    }

    // ==========================================================
    //                        ESTADO 4
    // ==========================================================
    else if (estado === 4) {
        const instruction = document.createElement('div');
        instruction.className = 'instruction-text';
        instruction.textContent = 'Toca en cualquier lugar para enviar un pulso y distorsionar el túnel';

        const pulseContainer = document.createElement('div');
        pulseContainer.className = 'pulse-container';

        const onContainerTap = (event) => {
            socket.emit('state4_send_pulse');
            console.log('Enviado: state4_send_pulse');

            const wave = document.createElement('div');
            wave.className = 'pulse-wave';
            
            const x = event.clientX;
            const y = event.clientY;
            const size = Math.max(window.innerWidth, window.innerHeight) * 0.2;

            wave.style.width = `${size}px`;
            wave.style.height = `${size}px`;
            wave.style.left = `${x - size / 2}px`;
            wave.style.top = `${y - size / 2}px`;

            pulseContainer.appendChild(wave);
            void wave.offsetWidth; 
            wave.classList.add('animate');
            
            setTimeout(() => { wave.remove(); }, 700);
        };

        pulseContainer.addEventListener('click', onContainerTap);

        appContainer.appendChild(instruction);
        appContainer.appendChild(pulseContainer);
    }
}


// --- INICIALIZACIÓN ---

// Llamamos a la función por primera vez para que dibuje la UI del estado inicial.
renderUIForState(estadoActual);

// Más adelante, escucharemos al servidor para cambiar de estado dinámicamente:

socket.on('cambio_estado', (nuevoEstado) => {
    estadoActual = nuevoEstado;
    renderUIForState(estadoActual);
});
